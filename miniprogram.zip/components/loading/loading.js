// components/loading/loading.js
Component({
  properties: {
    show: {
      type: Boolean,
      value: false
    },
    text: {
      type: String,
      value: '加载中...'
    }
  },

  data: {

  },

  methods: {
    
  }
}) 