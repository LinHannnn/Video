// utils/auth.js
const app = getApp()

// 微信登录
const wxLogin = () => {
  return new Promise((resolve, reject) => {
    wx.login({
      success: (res) => {
        if (res.code) {
          resolve(res.code)
        } else {
          reject(new Error('登录失败'))
        }
      },
      fail: reject
    })
  })
}

// 获取用户信息
const getUserInfo = () => {
  return new Promise((resolve, reject) => {
    wx.getUserProfile({
      desc: '用于完善用户资料',
      success: (res) => {
        app.globalData.userInfo = res.userInfo
        app.globalData.isLoggedIn = true
        wx.setStorageSync('userInfo', res.userInfo)
        resolve(res.userInfo)
      },
      fail: reject
    })
  })
}

// 检查登录状态
const checkLoginStatus = () => {
  const userInfo = wx.getStorageSync('userInfo')
  if (userInfo) {
    app.globalData.userInfo = userInfo
    app.globalData.isLoggedIn = true
    return true
  }
  return false
}

// 退出登录
const logout = () => {
  app.globalData.userInfo = null
  app.globalData.isLoggedIn = false
  wx.removeStorageSync('userInfo')
}

// 游客模式登录（开发测试用）
const guestLogin = () => {
  const guestInfo = {
    nickName: '游客用户',
    avatarUrl: '/images/default-avatar.png'
  }
  app.globalData.userInfo = guestInfo
  app.globalData.isLoggedIn = true
  wx.setStorageSync('userInfo', guestInfo)
  return Promise.resolve(guestInfo)
}

module.exports = {
  wxLogin,
  getUserInfo,
  checkLoginStatus,
  logout,
  guestLogin
} 