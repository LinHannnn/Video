// utils/api.js
const app = getApp()

const request = (url, options = {}) => {
  return new Promise((resolve, reject) => {
    const requestUrl = `${app.globalData.baseUrl}${url}`
    console.log('API请求地址:', requestUrl)
    console.log('请求数据:', options.data)
    
    wx.request({
      url: requestUrl,
      method: options.method || 'GET',
      data: options.data || {},
      header: {
        'Content-Type': 'application/json',
        ...options.header
      },
      success: (res) => {
        console.log('API响应:', res)
        if (res.statusCode === 200) {
          resolve(res.data)
        } else {
          reject(new Error(`请求失败: ${res.statusCode}`))
        }
      },
      fail: (err) => {
        console.error('API请求失败:', err)
        reject(err)
      }
    })
  })
}

// 视频解析API
const parseVideo = (url) => {
  return request('/api/video/parse', {
    method: 'POST',
    data: { url }
  })
}

// 获取支持的平台列表
const getSupportedPlatforms = () => {
  return request('/video/platforms')
}

// 健康检查
const healthCheck = () => {
  return request('/video/health')
}

module.exports = {
  parseVideo,
  getSupportedPlatforms,
  healthCheck
} 