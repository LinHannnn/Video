// pages/home/home.js
const util = require('../../utils/util.js')
const api = require('../../utils/api.js')

Page({
  data: {
    inputUrl: '',
    isLoading: false,
    showDisclaimer: false,
    videoInfo: null
  },

  onLoad() {
    // 页面加载时检查剪贴板
    this.checkClipboard()
  },

  onShow() {
    // 页面显示时重新检查剪贴板
    this.checkClipboard()
  },

  // 检查剪贴板内容
  async checkClipboard() {
    try {
      const clipboardData = await util.getClipboardData()
      if (clipboardData && util.isValidUrl(clipboardData) && clipboardData !== this.data.inputUrl) {
        const shouldPaste = await util.showModal('发现剪贴板链接', '是否粘贴剪贴板中的链接？')
        if (shouldPaste) {
          this.setData({
            inputUrl: clipboardData
          })
        }
      }
    } catch (error) {
      console.log('读取剪贴板失败:', error)
    }
  },

  // 输入框内容变化
  onInputChange(e) {
    this.setData({
      inputUrl: e.detail.value
    })
  },

  // 粘贴按钮点击
  async onPaste() {
    try {
      const clipboardData = await util.getClipboardData()
      if (clipboardData) {
        this.setData({
          inputUrl: clipboardData
        })
        util.showToast('粘贴成功', 'success')
      } else {
        util.showToast('剪贴板为空')
      }
    } catch (error) {
      util.showToast('粘贴失败')
      console.error('粘贴失败:', error)
    }
  },

  // 清空按钮点击
  onClear() {
    this.setData({
      inputUrl: '',
      videoInfo: null
    })
    util.showToast('已清空', 'success')
  },

  // 提取按钮点击
  onExtract() {
    const url = this.data.inputUrl.trim()
    if (!url) {
      util.showToast('请输入视频链接')
      return
    }

    if (!util.isValidUrl(url)) {
      util.showToast('请输入有效的链接地址')
      return
    }

    // 显示免责声明
    this.setData({
      showDisclaimer: true
    })
  },

  // 关闭免责声明弹窗
  onCloseDisclaimer() {
    this.setData({
      showDisclaimer: false
    })
  },

  // 阻止事件冒泡
  stopPropagation() {
    // 空函数，用于阻止点击模态框内容时关闭弹窗
  },

  // 确认并继续提取
  async onConfirmExtract() {
    this.setData({
      showDisclaimer: false,
      isLoading: true,
      videoInfo: null
    })

    try {
      util.showLoading('正在解析视频...')
      
      const result = await api.parseVideo(this.data.inputUrl.trim())
      
      if (result.code === 200 && result.data) {
        this.setData({
          videoInfo: result.data
        })
        util.showToast('解析成功', 'success')
        
        // 跳转到视频详情页面
        this.navigateToVideoDetail(result.data)
      } else {
        throw new Error(result.msg || '解析失败')
      }
    } catch (error) {
      console.error('视频解析失败:', error)
      util.showToast(error.message || '解析失败，请检查链接是否正确')
    } finally {
      util.hideLoading()
      this.setData({
        isLoading: false
      })
    }
  },

  // 复制下载链接
  async onCopyUrl(e) {
    const url = e.currentTarget.dataset.url
    if (!url) {
      util.showToast('链接不存在')
      return
    }

    try {
      await util.copyToClipboard(url)
    } catch (error) {
      util.showToast('复制失败')
      console.error('复制失败:', error)
    }
  },

  // 跳转到视频详情页面
  navigateToVideoDetail(videoInfo) {
    // 将视频信息保存到全局数据中
    const app = getApp()
    app.globalData.currentVideoInfo = videoInfo
    
    // 跳转到视频详情页面
    wx.navigateTo({
      url: '/pages/video-detail/video-detail',
      fail: (error) => {
        console.error('页面跳转失败:', error)
        util.showToast('页面跳转失败')
      }
    })
  },

  // 分享功能
  onShareAppMessage() {
    return {
      title: '视频提取助手 - 免费视频下载工具',
      path: '/pages/home/home',
      imageUrl: '/images/share-cover.png'
    }
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '视频提取助手 - 免费视频下载工具',
      imageUrl: '/images/share-cover.png'
    }
  }
}) 