// pages/video-detail/video-detail.js
const util = require('../../utils/util.js')

Page({
  data: {
    videoInfo: null,
    isPlaying: false,
    showControls: true,
    currentTab: 0, // 0: 视频, 1: 封面, 2: 文案
    tabs: ['视频', '封面', '文案']
  },

  onLoad(options) {
    // 从页面参数或全局数据中获取视频信息
    const app = getApp()
    if (options.videoData) {
      try {
        const videoInfo = JSON.parse(decodeURIComponent(options.videoData))
        this.setData({
          videoInfo: videoInfo
        })
      } catch (error) {
        console.error('解析视频数据失败:', error)
        this.goBack()
      }
    } else if (app.globalData.currentVideoInfo) {
      this.setData({
        videoInfo: app.globalData.currentVideoInfo
      })
    } else {
      util.showToast('视频信息不存在')
      this.goBack()
    }
  },

  onReady() {
    // 设置导航栏标题
    if (this.data.videoInfo && this.data.videoInfo.title) {
      wx.setNavigationBarTitle({
        title: this.data.videoInfo.title.length > 10 
          ? this.data.videoInfo.title.substring(0, 10) + '...' 
          : this.data.videoInfo.title
      })
    }
  },

  // 视频播放状态改变
  onVideoPlay() {
    this.setData({
      isPlaying: true
    })
  },

  onVideoPause() {
    this.setData({
      isPlaying: false
    })
  },

  onVideoEnded() {
    this.setData({
      isPlaying: false
    })
  },

  onVideoError(e) {
    console.error('视频播放错误:', e.detail)
    util.showToast('视频播放失败')
  },

  // 切换Tab
  onTabChange(e) {
    const index = e.currentTarget.dataset.index
    this.setData({
      currentTab: index
    })
  },

  // 获取文件大小格式化显示
  getFileSize() {
    const videoInfo = this.data.videoInfo
    if (!videoInfo) return ''
    
    // 如果有size字段直接返回
    if (videoInfo.size) {
      return videoInfo.size
    }
    
    // 否则返回默认提示
    return '未知大小'
  },

  // 下载视频
  async onDownload() {
    const videoInfo = this.data.videoInfo
    if (!videoInfo || !videoInfo.videoUrl) {
      util.showToast('视频链接不存在')
      return
    }

    try {
      util.showLoading('准备下载...')
      
      // 复制下载链接到剪贴板
      await util.copyToClipboard(videoInfo.videoUrl)
      util.hideLoading()
      
      // 提示用户
      wx.showModal({
        title: '下载提示',
        content: '视频下载链接已复制到剪贴板，请在浏览器中打开链接进行下载。',
        showCancel: false,
        confirmText: '知道了'
      })
    } catch (error) {
      util.hideLoading()
      console.error('下载失败:', error)
      util.showToast('下载失败，请稍后重试')
    }
  },

  // 复制视频链接
  async onCopyVideoUrl() {
    const videoInfo = this.data.videoInfo
    if (!videoInfo || !videoInfo.videoUrl) {
      util.showToast('视频链接不存在')
      return
    }

    try {
      await util.copyToClipboard(videoInfo.videoUrl)
    } catch (error) {
      util.showToast('复制失败')
      console.error('复制失败:', error)
    }
  },

  // 复制封面链接
  async onCopyCoverUrl() {
    const videoInfo = this.data.videoInfo
    const coverUrl = videoInfo.coverImage || videoInfo.coverUrl
    if (!videoInfo || !coverUrl) {
      util.showToast('封面链接不存在')
      return
    }

    try {
      await util.copyToClipboard(coverUrl)
    } catch (error) {
      util.showToast('复制失败')
      console.error('复制失败:', error)
    }
  },

  // 复制文案
  async onCopyTitle() {
    const videoInfo = this.data.videoInfo
    const title = videoInfo.title || videoInfo.work_title
    if (!videoInfo || !title) {
      util.showToast('文案不存在')
      return
    }

    try {
      await util.copyToClipboard(title)
    } catch (error) {
      util.showToast('复制失败')
      console.error('复制失败:', error)
    }
  },

  // 返回上一页
  goBack() {
    wx.navigateBack({
      delta: 1
    })
  },

  // 分享功能
  onShareAppMessage() {
    const videoInfo = this.data.videoInfo
    const title = videoInfo ? (videoInfo.title || videoInfo.work_title) : '视频提取助手'
    const coverUrl = videoInfo ? (videoInfo.coverImage || videoInfo.coverUrl) : null
    return {
      title: title,
      path: '/pages/home/home',
      imageUrl: coverUrl || '/images/share-cover.png'
    }
  },

  // 分享到朋友圈
  onShareTimeline() {
    const videoInfo = this.data.videoInfo
    const title = videoInfo ? (videoInfo.title || videoInfo.work_title) : '视频提取助手'
    const coverUrl = videoInfo ? (videoInfo.coverImage || videoInfo.coverUrl) : null
    return {
      title: title,
      imageUrl: coverUrl || '/images/share-cover.png'
    }
  }
}) 